/* bds-viral.js — 病毒分享循环（独立运行，不依赖 bds-core.js）
 * 每次工具输出结果后自动出现分享条：[📋 复制结果+链接] [📱 扫码]
 * 新用户通过 ?ref= 链接进来 → 自动绑定推荐关系 → 付费后推荐人返现
 * 影响范围：全部 5775 个工具页 + 5305 个游戏页
 */
(function(){
  "use strict";
  var VIRAL_DONE=false;
  function getRef(){
    try{return localStorage.getItem("bds_ref")||"";}catch(e){return "";}
  }
  function track(ev,d){
    try{
      var b=JSON.stringify({e:ev,d:d||{},p:location.pathname,t:Date.now()});
      if(navigator.sendBeacon)navigator.sendBeacon("/api/track",b);
      else fetch("/api/track",{method:"POST",headers:{"content-type":"application/json"},body:b,keepalive:true}).catch(function(){});
    }catch(err){}
  }
  function getToolName(){
    var t=document.getElementById("ttl");
    return t?t.textContent.trim().slice(0,50):document.title.slice(0,40);
  }
  function getResultText(){
    var o=document.getElementById("o");
    return o?o.textContent.trim().slice(0,80):"";
  }
  function injectShareBar(){
    if(document.getElementById("bds-viral-bar"))return;
    var o=document.getElementById("o");
    if(!o||!o.textContent.trim()||o.textContent.trim()==="0"||o.textContent.trim()==="")return;
    var ref=getRef();
    var shareUrl=location.origin+location.pathname+"?ref="+ref;
    var toolName=getToolName();
    var resultText=getResultText();
    var shareText=toolName+"："+resultText+"\n👉 免费试用："+shareUrl;
    var bar=document.createElement("div");
    bar.id="bds-viral-bar";
    bar.style.cssText="margin-top:12px;padding:10px 14px;background:#f0fdf4;border:1px solid #86efac;border-radius:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:14px";
    bar.innerHTML=
      '<span style="color:#166534">🎁 分享给需要的人，TA付费你返现</span>'+
      '<button id="bds-viral-copy" style="padding:6px 14px;background:#166534;color:#fff;border:0;border-radius:8px;font-size:13px;cursor:pointer">📋 复制结果+链接</button>'+
      '<button id="bds-viral-qr" style="padding:6px 14px;background:#07c160;color:#fff;border:0;border-radius:8px;font-size:13px;cursor:pointer">📱 扫码分享</button>';
    o.parentNode.insertBefore(bar,o.nextSibling);
    bar._shareText=shareText;
    bar._shareUrl=shareUrl;
    document.getElementById("bds-viral-copy").onclick=function(){
      var btn=this;
      if(navigator.clipboard){navigator.clipboard.writeText(shareText).then(function(){flash(btn);});}
      else{
        var ta=document.createElement("textarea");ta.value=shareText;
        document.body.appendChild(ta);ta.select();document.execCommand("copy");document.body.removeChild(ta);
        flash(btn);
      }
      track("share_copy",{slug:location.pathname.slice(0,50)});
    };
    document.getElementById("bds-viral-qr").onclick=function(){
      var existing=document.getElementById("bds-viral-qr-div");
      if(existing){existing.remove();return;}
      var qrDiv=document.createElement("div");
      qrDiv.id="bds-viral-qr-div";
      qrDiv.style.cssText="width:100%;text-align:center;padding:12px;background:#fff;border-radius:10px;margin-top:8px";
      bar.appendChild(qrDiv);
      loadQRLib(function(){
        try{
          var qr=window.qrcode(0,"M");qr.addData(shareUrl);qr.make();
          qrDiv.innerHTML=qr.createSvgTag({cellSize:4,margin:2,scalable:true});
          var hint=document.createElement("div");
          hint.style.cssText="font-size:12px;color:#666;margin-top:4px";
          hint.textContent="微信扫一扫，分享给需要的人";
          qrDiv.appendChild(hint);
        }catch(e){qrDiv.textContent=shareUrl;}
      });
      track("share_qr",{slug:location.pathname.slice(0,50)});
    };
    function flash(btn){
      btn.textContent="✓ 已复制";
      setTimeout(function(){btn.textContent="📋 复制结果+链接";},2000);
    }
    function loadQRLib(cb){
      if(window.qrcode){cb();return;}
      var urls=[
        "https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js",
        "https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js"
      ];
      (function tryUrl(i){
        if(i>=urls.length)return;
        var s=document.createElement("script");s.src=urls[i];
        s.onload=cb;s.onerror=function(){tryUrl(i+1);};
        document.head.appendChild(s);
      })(0);
    }
  }
  // 监听 #o 变化
  function startWatch(){
    var target=document.getElementById("o");
    if(!target){
      // 有时 DOM 还没渲染完，延迟重试
      setTimeout(startWatch,1000);
      return;
    }
    var obs=new MutationObserver(function(muts){
      if(VIRAL_DONE)return;
      var hasContent=target.textContent.trim()&&target.textContent.trim()!=="0";
      if(hasContent){
        VIRAL_DONE=true;
        setTimeout(injectShareBar,500);
      }
    });
    obs.observe(target,{childList:true,characterData:true,subtree:true});
  }
  // 启动
  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",startWatch);
  } else {
    startWatch();
  }
})();
