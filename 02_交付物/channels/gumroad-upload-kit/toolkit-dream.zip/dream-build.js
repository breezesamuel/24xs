// dream-build.js — 生成 1037 页解梦词典（免费基础解 + ¥9.9 深度全解包 CTA）
// 用法: node dream-build.js
const fs = require('fs');
const path = require('path');
const { DREAM_SYMBOLS } = require('./dream-data.js');

const ROOT = __dirname;
// 每类的内容片段池（按符号名 hash 取，保证同符号每次生成一致、不同符号不同组合）
const FRAG = {
  "动物": {
    base: "梦里的{S}通常与你本能层面的情绪有关——它可能是某种关系的化身，也可能是你自身某个性格侧面的投射。",
    psy: ["你的潜意识正在提醒你：有一股原始的情绪（保护欲/攻击性/依赖）没有被安放好。","它象征的忠诚与陪伴正在被你在现实中忽视，或者恰恰相反，你高估了一段关系。","这种生物的出现常和'领地感'相关——你最近是否感到自己的边界被人挤占？","它在梦里越安静，越说明你把某件事压得很深；越躁动，越说明快压不住了。"],
    trad: ["传统解梦里{S}多与人际、财运相连：遇之则变动将至，顺之则吉。","古人认为梦{S}主'信'与'义'，近期宜守诺，不宜与人立新约。","周公解梦一脉认为{S}入梦，起居有变，宜静养三日再决大事。"],
    act: ["本周内给一位老朋友发条消息。","把最近拖着的一个人际决定做了。","写下一件你'忍了很久'的事，然后决定：说，或者放下。"]
  },
  "人物": {
    base: "梦中出现的{S}几乎从来不是那个人本身，而是你心里与之相关的某种特质或未完成的事件。",
    psy: ["你在处理与'期待'有关的东西：你对某人的期待、某人对你的期待、或你对自己曾经的期待。","这个形象带着你投射出去的一部分自己——梦里越鲜明，现实中越回避。","人物在梦里的行为，往往是你希望（或害怕）自己在现实中做的事。"],
    trad: ["传统解梦认为梦里见{S}，主旧事重提；宜旧账清点，不宜新事务。","古法：梦见{S}，远信至；若梦中无言语，则所谋之事还需等待时机。"],
    act: ["本周联系一位你'一直想联系但没联系'的人。","把一句没说出口的话写在纸上，然后决定发不发。","复盘最近一次'没说出口'的对话。"]
  },
  "身体": {
    base: "梦里身体的{S}变化，通常与你的自我认同、控制感与健康焦虑相关，而非预示身体本身。",
    psy: ["潜意识在用身体做隐喻：失去/损伤/变化，对应的是现实中某种'失控感'。","它也可能在提醒你：你已经太久没有关注自己身体发出的真实信号了。","梦里越在意它，现实中越可能忽略它——这是一个反向信号。"],
    trad: ["传统解梦里{S}的变化，多主'去旧迎新'：旧的去掉，新的才有地方长。","古法认为梦见身体异变，主谋事有反复；宜固本，不宜冒进。"],
    act: ["今晚睡前做 10 分钟身体扫描（从头到脚）。","把最近一次体检/休息计划真正排进日程。","写下你最近忽略的身体信号。"]
  },
  "自然": {
    base: "{S}在梦里是'环境与趋势'的象征——它代表你感知到的外部力量，而非你自己。",
    psy: ["梦里的自然现象越剧烈，说明你对外部环境的不确定感越强。","它是你内心'天气预报'：不是预言，是你对现状的情绪渲染。","自然力通常不可控——梦里你的反应（躲/迎/旁观）才是重点。"],
    trad: ["传统解梦里{S}主'时局'与'运程'：顺则进，逆则守。","古法认为梦{S}，凡事看'势'，不逞强，不逆行。","周公解梦一脉认为{S}入梦，宜顺势而为，静待转机。"],
    act: ["列出你此刻无法控制的三件事，然后划掉能影响的那些。","本周做一件'顺势'而不是'逆势'的小决定。"]
  },
  "活动": {
    base: "梦里做{S}，通常映射的是你在现实中的'进度条'——它反映你对某件事推进状态的判断。",
    psy: ["梦里越顺利，现实中你越可能低估了自己的推进力；梦里越受阻，越说明你把目标定得太大。","活动的结果不重要，你在活动中的'角色感'（主动/被动）才是潜意识真正在说的。","反复做同一类活动的梦，说明这件事在你的优先级里被反复推迟。"],
    trad: ["传统解梦里梦{S}，主'事有反复'；成与不成，看梦中的情绪收尾。","古法：梦见{S}，宜稳不宜急，宜旧不宜新。"],
    act: ["把当前最大的目标拆成三步，只做第一步。","检查你的日历：最近一次为最重要的事留出整块时间是什么时候？"]
  },
  "物品": {
    base: "梦里的{S}象征'价值与拥有'——它可能与安全感、自我价值或即将到来的变化有关。",
    psy: ["物品的状态（新/旧/完整/损坏）往往对应你对某段关系或某个能力的自我评估。","得到物品的梦通常和'被认可'的需要有关；失去物品则和'失控'有关。","它在梦里越贵重，现实中你越可能低估了自己已经拥有的东西。"],
    trad: ["传统解梦里{S}主'财'与'信'：得之主进，失之主变。","古法认为梦{S}，宜盘点、宜守成；不宜与人争利。"],
    act: ["盘点你本周'得到'的三样东西（不只是钱）。","把一件'以为自己需要'的东西从购物车里删掉试试。"]
  },
  "场所": {
    base: "梦里的{S}是'处境'的象征——你此刻站在人生的哪个空间里，潜意识用它来标记。",
    psy: ["场所的开放/封闭、明亮/昏暗，对应你感受到的自由度与安全感。","熟悉的场所（如老家/学校）通常与'未完成的过去'有关。","陌生的场所则说明你正在进入一个自己还没建立心理模型的新阶段。"],
    trad: ["传统解梦里梦{S}，主'居所与根基'：迁与不迁，看梦中的光线。","古法认为梦见{S}，宜安不宜动，宜修不宜弃。"],
    act: ["整理你的真实居住空间的一角。","写下你现在'待着最舒服'的地方，以及为什么。"]
  },
  "情绪": {
    base: "梦见{S}本身——而不是引发情绪的事件——说明这种情绪已经积累到需要被单独看见的程度。",
    psy: ["情绪在梦里被'独立成场景'，是潜意识在要求处理权：它不想再当背景了。","梦里情绪的强度，通常低于现实中被压抑的强度——它是泄压阀，不是放大器。"],
    trad: ["传统解梦认为梦中{S}，主'心有未竟之事'；事宜疏不宜堵。"],
    act: ["给自己 15 分钟，不带手机地把这种情绪写下来。","告诉一个安全的人你最近的这种感受。"]
  },
  "抽象": {
    base: "梦里出现{S}这样超越日常的意象，通常与'边界感'有关——现实的某种规则在你心里松动了。",
    psy: ["抽象意象是潜意识最自由的表达：它不按现实逻辑来，是因为你的某种渴望本来就不按现实逻辑。","它常出现在转换期：换工作、换城市、换关系、换自我定义。"],
    trad: ["传统解梦对{S}类意象多为'变'字诀：变中有机，变中亦有险。"],
    act: ["写下你正在经历的一个'变化'，然后写下它带来的一个新选项。"]
  },
  "交通": {
    base: "梦里乘坐的{S}代表'你正在使用的路径与工具'——它关系到你对进度和方向的感受。",
    psy: ["交通工具的状态（正常/故障/失控）对应你对当下手段的信任度。","司机是谁很重要：自己开=掌控感；别人开=依赖或被动。"],
    trad: ["传统解梦里梦{S}，主'行程与时机'：宜早做打算，不宜临期仓促。"],
    act: ["检查你最重要的一个'进度'，确认它的下一站。","给最近一次'迟到/赶不上'的经历写一行复盘。"]
  },
  "食物": {
    base: "梦里与{S}有关的场景，通常与'滋养、享乐与匮乏感'相关——你最近在给自己补充什么、克扣什么。",
    psy: ["吃与不吃、味道好坏，对应你对生活中'值得不值得'的直觉判断。","它也可能和社交有关：饭桌是关系最古老的谈判桌。"],
    trad: ["传统解梦里梦{S}，主'口福与口舌'：得食者吉，争食者慎。"],
    act: ["认真吃一顿不带手机的饭。","本周给自己安排一次'值得的'款待。"]
  },
  "植物": {
    base: "梦里的{S}象征'生长与周期'——你在潜意识里正在跟踪某件事的成长进度。",
    psy: ["植物的状态（发芽/开花/枯萎）是你对某项长期投入的直觉评估。","它也可能关于耐心：植物的时间尺度和人的急躁永远不在一个频道。"],
    trad: ["传统解梦里梦{S}，主'生发与根基'：春种秋收，各有其时。","古法认为梦见{S}，宜培不宜拔，宜养不宜折。"],
    act: ["为你最重要的一项长期投入做一件'浇水'级别的小事。"]
  }
};

function hashStr(s){var h=0;for(var i=0;i<s.length;i++){h=(h*31+s.charCodeAt(i))>>>0;}return h;}

function pageFor(sym){
  var cat = sym.cat, name = sym.name;
  var f = FRAG[cat] || FRAG["抽象"];
  var h = hashStr(name);
  var base = f.base.replace(/\{S\}/g, name);
  var psy = f.psy[h % f.psy.length];
  var trad = f.trad[h % f.trad.length].replace(/\{S\}/g, name);
  var act = f.act[h % f.act.length];
  return { base: base, psy: psy, trad: trad, act: act };
}

function htmlFor(sym){
  var c = pageFor(sym);
  var enc = encodeURIComponent(sym.name);
  return '<!DOCTYPE html>\n<html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n'
  +'<title>梦见'+sym.name+'是什么意思 · 神算阁解梦词典（娱乐体验）</title>\n'
  +'<meta name="description" content="梦见'+sym.name+'的解析：基础含义、心理学视角、传统解梦视角与行动提示。神算阁解梦词典，文化娱乐体验，仅供参考。">\n'
  +'<link rel="canonical" href="https://tools.highkingflower.com/dream/'+enc+'/">\n'
  +'<style>*{box-sizing:border-box;margin:0}body{font-family:system-ui,"Microsoft YaHei";background:#0d0b1e;color:#e8e3f5;max-width:680px;margin:0 auto;padding:24px 16px 60px;line-height:2}\n'
  +'h1{font-size:26px;color:#d4b96a}.cat{color:#9a8fc0;font-size:13px;margin-bottom:16px}\n'
  +'.card{background:#181430;border:1px solid #3a2f6b;border-radius:16px;padding:20px;margin:14px 0}\n'
  +'.card h2{font-size:16px;color:#9a8fc0;margin-bottom:8px}\n'
  +'.btn{display:block;text-align:center;background:#d4b96a;color:#1a1530;font-weight:700;padding:14px;border-radius:12px;text-decoration:none;margin-top:16px}\n'
  +'.dis{font-size:12px;color:#6b6190;text-align:center;margin-top:24px}\n'
  +'a.nav{color:#9a8fc0;text-decoration:none;font-size:14px}\n</style></head><body>\n'
  +'<h1>梦见'+sym.name+'</h1>\n<div class="cat">分类：'+sym.cat+' · 神算阁解梦词典 · 娱乐体验</div>\n'
  +'<div class="card"><h2>基础含义</h2>'+c.base+'</div>\n'
  +'<div class="card"><h2>心理学视角</h2>'+c.psy+'</div>\n'
  +'<div class="card"><h2>传统解梦视角</h2>'+c.trad+'</div>\n'
  +'<div class="card"><h2>行动提示</h2>'+c.act+'</div>\n'
  +'<a class="btn" id="payLink" href="/api/pay?plan=dream&slug=dream">¥9.9 解锁「梦见'+sym.name+'」深度全解包（永久）</a>\n'
  +'<p class="dis">本页为文化娱乐内容，解梦为传统民俗与心理学视角的演绎，仅供娱乐与自我反思参考，不构成任何建议。</p>\n'
  +'<p style="text-align:center"><a class="nav" href="/dream/">← 返回解梦词典</a> · <a class="nav" href="/">神算阁工具箱</a></p>\n'
  +'<script>try{var r=localStorage.getItem("bds_ref")||"";var pl=document.getElementById("payLink");if(pl&&r)pl.href="/api/pay?plan=dream&slug=dream&ref="+encodeURIComponent(r);var q=new URLSearchParams(location.search);if(q.get("paid")==="1"){var bs=document.querySelectorAll(".btn");bs.forEach(function(b){b.style.display="none";});var d=document.createElement("div");d.className="card";d.innerHTML="<h2>深度全解包已解锁</h2><p>感谢支持！深度内容已随本次更新推送至你的邮箱（下单邮箱）。你也可以收藏本页随时回看基础内容。</p>";document.body.insertBefore(d,document.querySelector(".dis"));\}}catch(e){}<\/script>\n'
  +'</body></html>\n';
}

// 生成
var count = 0;
DREAM_SYMBOLS.forEach(function(sym){
  var enc = encodeURIComponent(sym.name);
  var dir = path.join(ROOT, enc);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), htmlFor(sym));
  count++;
});
console.log('generated', count, 'dream pages');
