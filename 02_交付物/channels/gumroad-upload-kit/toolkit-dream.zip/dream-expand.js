const fs=require('fs'),path=require('path');
eval(fs.readFileSync(path.join(__dirname,'dream-data.js'),'utf8'));
const ROOT=path.join(__dirname);
const buildTemplate=fs.readFileSync(path.join(__dirname,'dream-build.js'),'utf8');
// 从 dream-build.js 提取 htmlFor 函数逻辑（简化版）
function hashStr(s){var h=0;for(var i=0;i<s.length;i++){h=(h*31+s.charCodeAt(i))>>>0;}return h%100;}

const FRAG={
"动物":{psy:["你的潜意识正在处理某种本能层面的情绪——保护欲、攻击性或依赖感。","它象征的忠诚或陪伴可能被你在现实中忽视了。","这种生物的出现在提醒你注意自己的边界感。","它在梦里的状态反映了你压住某件事的程度。"],"trad":["传统解梦认为此梦与人际变动和财运波动相关。","古法认为这类梦境主'信'与'义'，近期宜守诺。","周公解梦一脉认为此梦预示起居有变，宜静养后再决大事。"],"act":["本周给一位老朋友发条消息。","把一个拖着的人际决定做了。"]},
"人物":{psy:["你在处理与'期待'有关的东西——某人对你的期待，或你对自己的期待。","这个形象带着你投射出去的一部分自己。","人物的行为往往是你在现实中希望或害怕做的事。"],"trad":["传统解梦认为梦见此类人物主旧事重提，宜清点不宜展开。","古法认为此梦主远信将至，若无言语则需等待时机。"],"act":["联系一位'一直想联系但没联系'的人。","写下一句没说出口的话。"]},
"身体":{psy:["潜意识在用身体做隐喻：变化对应的是失控感。","你太久没有关注身体发出的真实信号了。","梦里越在意，现实中越可能忽略——反向信号。"],"trad":["传统解梦认为身体异变主'去旧迎新'。","古法认为此梦主谋事反复，宜固本不宜冒进。"],"act":["今晚做 10 分钟身体扫描。","把体检计划排进日程。"]},
"自然":{psy:["梦里的自然现象是你对环境不确定感的渲染。","它不是预言，是你的情绪天气预报。","你的反应（躲/迎/旁观）才是关键。"],"trad":["传统解梦认为此梦看'势'：顺则进，逆则守。","古法认为此梦宜顺势而为，静待转机。"],"act":["列出无法控制的事，划掉能影响的。","本周做一个'顺势'的小决定。"]},
"活动":{psy:["梦里活动的顺利程度反映你对推进状态的判断。","梦里越顺利，现实越可能低估推进力；越受阻，越说明目标定得太大。","角色感（主动/被动）是关键信号。"],"trad":["传统解梦认为梦此类活动主'事有反复'。","古法认为宜稳不宜急，宜旧不宜新。"],"act":["把最大目标拆三步，只做第一步。","检查日历：上次为最重要的事留整块时间是什么时候？"]},
"物品":{psy:["物品的状态对应你对某段关系或能力的自我评估。","得到物品与'被认可'有关，失去与'失控'有关。","越贵重，现实中越可能低估已拥有的。"],"trad":["传统解梦认为物品主'财'与'信'。","古法认为宜盘点守成，不宜争利。"],"act":["盘点本周'得到'的三样东西。"]},
"场所":{psy:["场所是你对自由度与安全感的感觉标记。","熟悉场所关联未完成的过去，陌生场所说明在进入新阶段。"],"trad":["传统解梦认为场所梦主'居所与根基'。","古法认为宜安不宜动。"],"act":["整理居住空间的一角。"]},
"情绪":{psy:["情绪被独立成场景，说明它需要被处理了。","梦里情绪强度通常低于现实中被压抑的强度。"],"trad":["传统解梦认为情绪梦主'心有未竟之事'。"],"act":["15 分钟不带手机写下来。","告诉一个安全的人。"]},
"抽象":{psy:["超越日常的意象与边界感有关——规则在你心里松动了。","它们常出现在转换期。"],"trad":["传统解梦对此类意象多为'变'字诀。"],"act":["写下一个变化和一个新选项。"]},
"交通":{psy:["交通工具的状态对应你对手段的信任度。","司机是谁很重要：自己开=掌控，别人开=依赖。"],"trad":["传统解梦认为交通梦主'行程与时机'。"],"act":["检查最重要进度的下一站。"]},
"食物":{psy:["与滋养、享乐和匮乏感相关。","也可能和社交谈判有关。"],"trad":["传统解梦认为食物梦主'口福与口舌'。"],"act":["认真吃一顿不带手机的饭。"]},
"植物":{psy:["植物的生长状态是你对长期投入的直觉评估。","植物的时间尺度和人的急躁不在一个频道。"],"trad":["传统解梦认为植物梦主'生发与根基'。"],"act":["为长期投入做一件'浇水'级别的事。"]}
};
function getCategory(symName){
  for(var cat of Object.keys(DREAM_CATS)){
    if(DREAM_CATS[cat].some(function(s){return symName.includes(s)||s.includes(symName);}))return cat;
  }
  return "抽象";
}
// 生成子变体
var VARIANTS=[];
var RULES=[
  {pattern:"{S}追我",cat:"活动"},
  {pattern:"{S}说话",cat:"抽象"},
  {pattern:"{S}飞走了",cat:"抽象"},
  {pattern:"{S}进家",cat:"场所"},
  {pattern:"白{S}",cat:"抽象"},
  {pattern:"黑{S}",cat:"抽象"},
  {pattern:"{S}在水里",cat:"自然"},
  {pattern:"杀死{S}",cat:"活动"},
];
DREAM_SYMBOLS.forEach(function(s){
  if(s.cat!=="动物"&&s.cat!=="人物")return;
  RULES.forEach(function(r){
    var name=r.pattern.replace("{S}",s.name);
    VARIANTS.push({cat:r.cat,name:name,base:s.name});
  });
});
console.log("variant count:",VARIANTS.length);
// 生成页面
var count=0,skipped=0;
VARIANTS.forEach(function(v){
  var enc=encodeURIComponent(v.name);
  var dir=path.join(ROOT,enc);
  if(fs.existsSync(path.join(dir,'index.html'))){skipped++;return;}
  fs.mkdirSync(dir,{recursive:true});
  var cat=v.cat;
  var f=FRAG[cat]||FRAG["抽象"];
  var h=hashStr(v.name);
  var base="梦见"+v.name+"——在传统解梦体系中，这是"+(v.base?"与「"+v.base+"」相关的延伸场景":"一个独立的梦境符号")+"。"
    +"梦里"+(v.name.includes("追")?"被追赶代表你在逃避某个需要面对的事。":v.name.includes("说话")?"会说话的梦里生物代表你的直觉在用不寻常的方式传递信息。":v.name.includes("白")?"白色通常与纯洁、新生或精神层面相关。":v.name.includes("黑")?"黑色常与未知、潜意识深处或未处理的情绪有关。":v.name.includes("死")?"死亡在梦中几乎从不代表真实的死亡——它代表结束与转变。":"这个意象在提醒你注意某个被忽视的面向。");
  var psy=f.psy[h%f.psy.length];
  var trad=f.trad[h%f.trad.length];
  var act=f.act[h%f.act.length];
  var html='<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    +'<title>梦见'+v.name+'是什么意思 · 神算阁解梦词典</title>'
    +'<meta name="description" content="梦见'+v.name+'的解析：基础含义、心理学视角、传统解梦视角。神算阁解梦词典，文化娱乐体验。">'
    +'<link rel="canonical" href="https://tools.highkingflower.com/dream/'+enc+'/">'
    +'<style>*{box-sizing:border-box;margin:0}body{font-family:system-ui,"Microsoft YaHei";background:#0d0b1e;color:#e8e3f5;max-width:680px;margin:0 auto;padding:24px 16px 60px;line-height:2}'
    +'h1{font-size:24px;color:#d4b96a}.cat{color:#9a8fc0;font-size:13px;margin-bottom:14px}.card{background:#181430;border:1px solid #3a2f6b;border-radius:16px;padding:18px;margin:12px 0}'
    +'.card h2{font-size:15px;color:#9a8fc0;margin-bottom:8px}.btn{display:block;text-align:center;background:#d4b96a;color:#1a1530;font-weight:700;padding:13px;border-radius:12px;text-decoration:none;margin-top:14px}'
    +'.dis{font-size:12px;color:#6b6190;text-align:center;margin-top:20px}a.nav{color:#9a8fc0;text-decoration:none;font-size:14px}'
    +'</style></head><body>'
    +'<h1>梦见'+v.name+'</h1><div class="cat">分类：'+cat+' · 神算阁解梦词典 · 娱乐体验</div>'
    +'<div class="card"><h2>梦境含义</h2>'+base+'</div>'
    +'<div class="card"><h2>心理学视角</h2>'+psy+'</div>'
    +'<div class="card"><h2>传统解梦视角</h2>'+trad+'</div>'
    +'<div class="card"><h2>行动提示</h2>'+act+'</div>'
    +'<a class="btn" href="/api/pay?plan=dream&slug=dream">¥9.9 解锁「梦见'+v.name+'」深度全解包</a>'
    +'<p class="dis">文化娱乐内容，仅供娱乐参考 · <a class="nav" href="/dream/">返回词典</a></p>'
    +'</body></html>\n';
  fs.writeFileSync(path.join(dir,'index.html'),html);
  count++;
});
console.log('generated:',count,'| skipped:',skipped);
